public class Colors { //a class specifically for colors
  public String reset = "\u001B[0m";
  public String black = "\u001B[30m";
  public String red = "\u001B[31m";
  public String green = "\u001B[32m";
  public String yellow = "\u001B[33m";
  public String blue = "\u001B[34m";
  public String purple = "\u001B[35m";
  public String cyan = "\u001B[36m";
  public String white = "\u001B[37m";
}

